﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    internal class Ship
    {
        //klasa, reprezentująca statek
        private int mass { get; set; }

        //właściwość - silnik statku
        public Engine Engine { get; set; }

        //właściwość - masa niezaładowanego statku

        //konstruktor tworzący defaultowy statek 
        public Ship()
        {
            Engine = new Engine(Engine.Fuel.Diesel);
            mass = 20;
        }
        public Ship(Engine engine, int masa)
        {
            Engine = engine;
            if (masa > 0)
                mass = masa;
            else mass = 0;
        }

        public bool TravelOffer(Destination cel, Product produkt1, Product produkt2)
        {
            int cena = produkt1.GetCurrentValue() + produkt2.GetCurrentValue();
            int masa = produkt1.Mass + produkt2.Mass + mass;
            int koszty = Engine.TravelCost(cel.Distance, masa);

            if(cena - koszty >= 1000)
            {
                Console.WriteLine("Accepted " + cel.Name);
                Console.WriteLine(produkt1.Name + ": " + produkt1.Mass + " tons");
                Console.WriteLine(produkt2.Name + ": " + produkt2.Mass + " tons");
                Console.WriteLine("Travel time: " + Engine.TravelTime(cel.Distance, masa) + " hours");
                Console.WriteLine("Travel cost: " +  koszty);
                Console.WriteLine("Selling cost: " + cena);
                return true;
            }
            else
            {
                Console.WriteLine(cel.Name + ": Offer declined.");
                return false;
            }
        }

    }
}
