﻿using System;
using System.Collections.Generic;

namespace B6
{
    class Program
    {
        static void Main(string[] args)
        {
            List<HighestPeak> homework = Homework.CreateList();

            //dane na temat Austrii
            Console.WriteLine("Dane na temat Austrii: ");

                        var austria =
        from eva in homework
        where eva.Country == "Austria"
        select new
        {
                elevation = eva.Elevation,
                country = eva.Country,
                name = eva.Name
        };

            foreach (var item in austria)
            { Console.WriteLine("Country: " + item.country + " Name: " + item.name + " Elevation: " + item.elevation); }

            Console.WriteLine("\nPrzedostatni kraj na liscie: ");

            int dlugosc = homework.Count-2;
            HighestPeak highestPeak = homework[dlugosc];
            highestPeak.ShowInfo();

            //srednia arytmetyczna
            double s = 0;
            var srednia =
        from eva in homework
        select new
        {
            elevation = eva.Elevation,
            country = eva.Country,
            name = eva.Name
        };

            foreach (var item in srednia)
            {
                s = s + item.elevation;
            }
            Console.WriteLine("\nSrednia wysokosci szczytow wynosi: " + s/(homework.Count) + "m");

            //Szczyty od 4000 do 5000
            Console.WriteLine("\nSzczyty z przedziału <4000,5000>:");
            var najwyzszeszczyty =
    from szczyty in homework
    where szczyty.Elevation >= 4000 & szczyty.Elevation <= 5000
    select new
    {
        imionko = szczyty.Name,
        szczycik = szczyty.Elevation
    };
            foreach (var item in najwyzszeszczyty)
            {
                Console.WriteLine(item.imionko + ", wysokosc: " + item.szczycik + "m");
            }

            //sortowanie i 10 najnizszych
            Console.WriteLine("\n10 najnizszych szczytow: ");
            var sortowanie =
    from najwyzsze in homework
    orderby najwyzsze.Elevation
    select new
    {
        country = najwyzsze.Country,
        nazwa = najwyzsze.Name,     
        elevation = najwyzsze.Elevation
    };
            int b = 0;
            foreach (var item in sortowanie)
            {
                Console.WriteLine("Country: " + item.country + ", Name: " + item.nazwa + "Elevation: " + item.elevation);
                b++;
                if (b == 10) break;
            }
///////////////////////////////////////////////////////////////////////////////////////////

            Dictionary<string,double> slownik = Homework.CreateDictionary();
            //Ktory kraj ma 5.5 mln mieszkancow
            Console.WriteLine("\nKraj, ktory ma 5.5 mln mieszkancow: ");
            foreach(KeyValuePair<string,double> item in slownik)
            {
                if (item.Value == 5.5)
                    Console.WriteLine(item.Key + ": " + item.Value);
            }
            //Dodaj kraj i wyswietl nowa liczbe pozycji w slowniku
            slownik.Add("Novigrad", 2.4);
            int pozycje = slownik.Count;
            Console.WriteLine("\nNowa liczba krajow: " + pozycje);

            //Srednia arytmetyczna populacji
            double suma = 0;
            foreach (KeyValuePair<string, double> item in slownik)
            {
                suma = suma + item.Value;
            }
            Console.WriteLine("\nSrednia populacji wynosi: " + suma/pozycje);

            //kraje o populacji pomiędzy 10 a 20 milionow
            Console.WriteLine("\nKraje o populacji <10,20>mln: ");
            foreach (KeyValuePair<string, double> item in slownik)
            {
                if(item.Value>=10 & item.Value<=20)
                    Console.WriteLine(item.Key + ": " + item.Value);
            }
            double mieszkancy = 0;
            //populacja krajow baltyckich
            Console.WriteLine("\nPopulacja krajow baltyckich: ");
            foreach (KeyValuePair<string, double> item in slownik)
            {
                if (item.Key == "Lithuania" || item.Key == "Latvia" || item.Key == "Estonia")
                    mieszkancy = mieszkancy + item.Value;
            }
            Console.WriteLine("\nSumaryczna populacja krajow baltyckich: " + mieszkancy);
        }
        }
    }

