﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    internal class WorldMarket
    {
        
        public static int GetInitialPricePerKg()
        {
            Random random = new Random();
            int pricePerKg = random.Next(100, 1000);
            return pricePerKg;
        }
        public static int GetNewPricePerKg(int initialprice)
        {
            Random rand = new Random();
            int modification = rand.Next(-50, 200);
            return  initialprice-modification;
        }

    }
}
