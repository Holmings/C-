﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace B4
{
    class Program
    {
        static void Main(string[] args)
        {
            List<string> words = ZadanieDomowe.Read();

            // A
            List<string> answerA = words.Where(x => x.Length == 13).ToList();
            foreach (string word in answerA) Console.WriteLine(word);
            Console.WriteLine();

            // B
            List<char> answerB = words.Select(x => x.FirstOrDefault()).ToList();
            for (int i = 0; i < 20; i++) Console.WriteLine(answerB[i]);
            Console.WriteLine();

            // C
            List<string> answerC = words.Select(x => x.Replace("i","a").Replace("e", "a").Replace("o", "a").Replace("u", "a").Replace("y", "a").Replace("I", "a").Replace("E", "a").Replace("O", "a").Replace("U", "a").Replace("Y", "a")).ToList();
            for (int i = 0; i < 20; i++) Console.WriteLine(answerC[i]);
            Console.WriteLine();

            // F
            bool answerF = words.FindAll(x => x.Length > 10).Contains("z");
            Console.WriteLine(answerF);
            Console.WriteLine();

            // G
            int answerG = words.Select(x => x.Length).Sum();
            Console.WriteLine(answerG);
            Console.WriteLine();
        }

    }
}
