﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    class Destination
    {
        // właściwość - nazwa docelowego miejsca
        public string Name { get; }

        // właściwość - dystans między portami
        public int Distance { get; }

        // konstrutkor ustawiający nazwę i odległość do docelowego portu
        public Destination(int distance, string name)
        {
            Name = name;
            if (distance > 0)
            {
                Distance = distance;
            }
            else
            {
                Console.WriteLine(distance + " is not >0.");
                Console.WriteLine("Setting distance to default option - 1000 km.");
                Distance = 1000;
            }
        }
    }
}
