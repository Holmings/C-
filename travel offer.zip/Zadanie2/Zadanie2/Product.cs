﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace B2
{
    internal class Product
    {
        int CurrentPrice;
        public string Name { get; }
        private int _mass;
        public int Mass { get { return _mass; } set { if (value > 0) _mass = value; }}

        public Product(string nazwa, int masa)
        {
            Name = nazwa;
            if (masa > 0)
                _mass = masa;
            else Console.WriteLine("Negative mass!");
        }

        int iniprice = WorldMarket.GetInitialPricePerKg();
        
        public int GetCurrentValue()
        {
             int newprice = WorldMarket.GetNewPricePerKg(iniprice);
            return newprice*_mass;
        }

       
    }
}
